Simple word guessing game where user is given 6 chances to guess a 6 alphabet word 
Game will remain continue until user enter 0.
If player guess correct alphabets befor 6 chances that player wins and game will reset.