package Task;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class gussingGame {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int status = 0;
		do {
			System.out.println("Play---->press 1 ");
			System.out.println("Exit---->press 0 ");
			status = sc.nextInt();
			switch(status) {
			case 0:
				System.out.println("End");
				sc.close();
				break;
			case 1:
				status = 1;
				
				String arr[] = {"Better","Beyond","Bishop","Camera","Cancer","Cannot","Carbon","Damage","Danger","Dealer"};
				String word = arr[(int) (Math.random()*arr.length)].toLowerCase();
				Map<Character, Boolean> map = new HashMap<>();
				for(int i=0;i<word.length();i++) {
					if(!map.containsKey(word.charAt(i))) {
						map.put(word.charAt(i), false);
					}
				}
				
				System.out.println("Welcome to word guessing game");
				System.out.println("  -->You have 6 chance to guess alphabets of a word ");
				System.out.println("  -->If you choose correct alphabets in given chances, you WIN else you LOOSE");
				System.out.println();
				int count = 0;
				for(int i=0;i<6;i++) {
					
					if(count==6) {
						break;
						}else {
							count =0;
						}
					System.out.println("Guess alphabet");
					char guess = sc.next().charAt(0);
					if(map.containsKey(guess)) {
						map.put(guess, true);
					}
					for(int j=0;j<6;j++) {
						if(map.get(word.charAt(j))) {
							System.out.print(word.charAt(j)+" ");
							++count;
						}else {
							System.out.print("_ ");
						}
					}
					System.out.println();
					
				}
				
				System.out.println("------------------------------------------");
				if(count==6) {
				System.out.println("You WIN");
				}else {
					System.out.println("Better luck next time");
				}
				System.out.println("------------------------------------------");
			
				break;
			default:
				System.out.println("Please enter valid input...");
			}
		}while(status!=0);
		}
	
}
